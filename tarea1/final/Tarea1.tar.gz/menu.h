//Tarea 1
// Ricardo Churion, carnet:11-10200
// Douglas Torres, carnet:11-11027

PREGUNTA *leer (FILE fp);
void mostrartodas(PREGUNTA *preguntas);
void mostraralgunas(PREGUNTA *preguntas);
PREGUNTA *eliminar(PREGUNTA *preguntas);
PREGUNTA *agregar(PREGUNTA *preguntas);
void guardar(char archivo, PREGUNTA *preguntas);