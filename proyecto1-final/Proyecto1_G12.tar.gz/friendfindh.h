void *map (HILOS *argumento);
COMPARACION *agregar(LISTA *listaAmigos, COMPARACION *estructura);
void *reduce (HILOS *argumento);
LISTA *agregarLista (char *nombre, AMIGOS *comunes, LISTA *definitivo);