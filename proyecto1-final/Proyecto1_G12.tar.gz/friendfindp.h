LISTA *map (LISTA *lista, COMPARACION *estructura);
COMPARACION *agregar(LISTA *listaAmigos, COMPARACION *estructura);
void *reduce (COMPARACION *estructura, char *salida);
void escribir(LISTA *definitivo, char *salida);
struct LISTA *leer(FILE *file);